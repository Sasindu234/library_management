document.addEventListener('DOMContentLoaded', function () {
    // Select common elements that are used in multiple pages
    const messageDiv = document.getElementById('message');

    // ** Add Book Page **  
    const addBookForm = document.getElementById('addBookForm');
    const booksTableBody = document.getElementById('booksTableBody');
    
    if (addBookForm && booksTableBody) {
        // Function to fetch and display books
        function fetchBooks() {
            fetch('http://localhost/library_management/backend/fetch_books.php')
                .then(response => response.json())
                .then(books => {
                    booksTableBody.innerHTML = ''; // Clear the table before adding new rows

                    if (Array.isArray(books) && books.length > 0) {
                        books.forEach(book => {
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td>${book.book_id}</td>
                                <td>${book.title}</td>
                                <td>${book.author}</td>
                                <td>${book.isbn}</td>
                                <td>${book.genre}</td>
                                <td>${book.publication_year}</td>
                                <td>${book.availability ? 'Available' : 'Not Available'}</td>
                            `;
                            booksTableBody.appendChild(row);
                        });
                    } else {
                        const row = document.createElement('tr');
                        row.innerHTML = '<td colspan="7">No books available.</td>';
                        booksTableBody.appendChild(row);
                    }
                })
                .catch(error => {
                    console.error('Error fetching books:', error);
                });
        }

        // Fetch books when the page loads
        fetchBooks();

        // Handle form submission for adding a book
        addBookForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(addBookForm);

            fetch('http://localhost/library_management/backend/add_books.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.message) {
                    if (messageDiv) {
                        messageDiv.textContent = data.message;
                        messageDiv.style.color = 'green';
                    }
                    fetchBooks(); // Refresh the books table
                    addBookForm.reset(); // Reset the form after adding the book
                } else if (data.error) {
                    if (messageDiv) {
                        messageDiv.textContent = data.error;
                        messageDiv.style.color = 'red';
                    }
                }
            })
            .catch(error => {
                console.error('Error adding book:', error);
                if (messageDiv) {
                    messageDiv.textContent = 'There was an error adding the book. Please try again.';
                    messageDiv.style.color = 'red';
                }
            });
        });
    }

    // ** Manage Customers Page **
    const customersTableBody = document.getElementById('customersTableBody');
    const addCustomerForm = document.getElementById('addCustomerForm');
    const addCustomerModal = document.getElementById('addCustomerModal');
    const closeModalButton = document.querySelector('.close');

    if (customersTableBody && addCustomerForm) {
        // Function to fetch and display customers
        function fetchCustomers() {
            fetch('http://localhost/library_management/backend/fetch_customers.php')
                .then(response => response.json())
                .then(customers => {
                    customersTableBody.innerHTML = ''; // Clear the table before adding new rows

                    if (Array.isArray(customers) && customers.length > 0) {
                        customers.forEach(customer => {
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td>${customer.customer_id}</td>
                                <td>${customer.name}</td>
                                <td>${customer.user_id}</td>
                                <td>${customer.phone_number}</td>
                                <td>${customer.late_fees}</td>
                                <td>${customer.books_rented_out}</td>
                            `;
                            customersTableBody.appendChild(row);
                        });
                    } else {
                        const row = document.createElement('tr');
                        row.innerHTML = '<td colspan="6">No customers available.</td>';
                        customersTableBody.appendChild(row);
                    }
                })
                .catch(error => {
                    console.error('Error fetching customers:', error);
                });
        }

        // Fetch customers when the page loads
        fetchCustomers();

        // Handle form submission for adding a customer
        addCustomerForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(addCustomerForm);

            fetch('http://localhost/library_management/backend/add_customer.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.message) {
                    if (messageDiv) {
                        messageDiv.textContent = data.message;
                        messageDiv.style.color = 'green';
                    }
                    fetchCustomers(); // Refresh the customers table
                    addCustomerForm.reset(); // Reset the form after adding the customer
                    addCustomerModal.style.display = 'none'; // Close the modal
                } else if (data.error) {
                    if (messageDiv) {
                        messageDiv.textContent = data.error;
                        messageDiv.style.color = 'red';
                    }
                }
            })
            .catch(error => {
                console.error('Error adding customer:', error);
                if (messageDiv) {
                    messageDiv.textContent = 'There was an error adding the customer. Please try again.';
                    messageDiv.style.color = 'red';
                }
            });
        });

        // Show the modal when the "Add Customer" button is clicked
        const addCustomerBtn = document.getElementById('addCustomerBtn');
        if (addCustomerBtn) {
            addCustomerBtn.addEventListener('click', function() {
                addCustomerModal.style.display = 'block';
            });
        }

        // Close the modal when the close button is clicked
        if (closeModalButton) {
            closeModalButton.addEventListener('click', function() {
                addCustomerModal.style.display = 'none';
            });
        }

        // Close the modal if the user clicks outside the modal content
        window.addEventListener('click', function(event) {
            if (event.target === addCustomerModal) {
                addCustomerModal.style.display = 'none';
            }
        });
    }

    // ** Admin Panel Page (if any page-specific functionality needed) **
    const adminPanelElement = document.getElementById('adminPanel');
    if (adminPanelElement) {
        // Add any admin panel specific functionalities here
        // Make sure to add the relevant elements to the admin panel page (e.g., buttons, forms).
    }
}); // <-- Make sure this closing parenthesis and brace is here!
