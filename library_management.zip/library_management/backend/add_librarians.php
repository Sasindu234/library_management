<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

include 'db_connect.php';

$response = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $user_id = $_POST['user_id'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO librarian (name, user_id, password) VALUES ('$name', '$user_id', '$password')";

    if ($conn->query($sql) === TRUE) {
        $response['message'] = "Librarian added successfully";
    } else {
        $response['error'] = "Error: " . $conn->error;
    }
} else {
    $response['error'] = "Invalid request method";
}

$conn->close();
echo json_encode($response);
?>
