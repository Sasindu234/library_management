<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set the correct content-type for the response
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

include 'db_connect.php';

$response = [];

// Use prepared statement to prevent SQL injection
try {
    $stmt = $conn->prepare("SELECT customer_id, name, user_id, phone_number, late_fees, books_rented_out FROM customer");
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Store customers in response
        while ($row = $result->fetch_assoc()) {
            $response[] = $row;
        }
    } else {
        // No customers found
        $response['error'] = "No customers found";
    }

    $stmt->close();
} catch (Exception $e) {
    // Handle errors with a message
    $response['error'] = "Query failed: " . $e->getMessage();
}

$conn->close();

// Return the response as JSON
echo json_encode($response);
?>
