<?php
// Allow access from any origin (you can specify your domain instead of '*' if needed)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Ensure you're sending a proper content type header for JSON
header('Content-Type: application/json');

// Include database connection
include 'db_connect.php';

// Check for database connection errors
if ($conn->connect_error) {
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// SQL query to fetch books
$sql = "SELECT * FROM books";
$result = $conn->query($sql);

// Check if any books were returned
if ($result->num_rows > 0) {
    $books = [];
    while ($row = $result->fetch_assoc()) {
        $books[] = $row;
    }
    echo json_encode($books); // Return the books as JSON
} else {
    echo json_encode(["error" => "No books found."]); // Return an error if no books
}

// Close the database connection
$conn->close();
?>
