<?php
include 'db.php';

$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM librarian WHERE librarian_id = $id");
echo json_encode(['message' => "Librarian deleted"]);
?>
