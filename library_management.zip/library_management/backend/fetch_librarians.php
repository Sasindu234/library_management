<?php
// Allow cross-origin requests
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Set the correct content-type for the response
header("Content-Type: application/json");

// Include database connection
include 'db_connect.php';

$response = [];

// Query to get all librarians
$stmt = $conn->prepare("SELECT librarian_id, name, user_id FROM librarian");
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $response[] = $row;
    }
} else {
    $response['error'] = "No librarians found";
}

$stmt->close();
$conn->close();

echo json_encode($response);
?>
