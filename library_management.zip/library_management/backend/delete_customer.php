<?php
include 'db.php';

$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM customer WHERE customer_id = $id");
echo json_encode(['message' => "Customer deleted"]);
?>
